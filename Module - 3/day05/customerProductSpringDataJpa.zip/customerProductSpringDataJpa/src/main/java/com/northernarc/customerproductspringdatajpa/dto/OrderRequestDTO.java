package com.northernarc.customerproductspringdatajpa.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
public class OrderRequestDTO {

    @PastOrPresent
    private LocalDate orderDate;

    @NotNull
    private Long customerId;

    @Valid
    @NotEmpty
    private List<OrderItemRequestDTO> orderItems;
}
