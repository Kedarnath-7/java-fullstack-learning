package com.northernarc.customerproductspringdatajpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerProductSpringDataJpaApplicationTests {

    @Test
    void contextLoads() {
    }

}
