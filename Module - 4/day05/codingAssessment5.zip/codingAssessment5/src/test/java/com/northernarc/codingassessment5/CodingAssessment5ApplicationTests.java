package com.northernarc.codingassessment5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodingAssessment5ApplicationTests {

    @Test
    void contextLoads() {
    }

}
