package com.northernarc.codingassessment5.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.northernarc.codingassessment5.dto.DepositRequest;
import com.northernarc.codingassessment5.dto.TransferRequest;
import com.northernarc.codingassessment5.dto.WithdrawRequest;
import com.northernarc.codingassessment5.exception.AccountNotFoundException;
import com.northernarc.codingassessment5.exception.ValidationException;
import com.northernarc.codingassessment5.model.Account;
import com.northernarc.codingassessment5.model.Transaction;
import com.northernarc.codingassessment5.security.JwtAuthFilter;
import com.northernarc.codingassessment5.security.JwtUtil;
import com.northernarc.codingassessment5.service.AccountService;
import com.northernarc.codingassessment5.service.TransactionService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AccountController.class)
@AutoConfigureMockMvc(addFilters = false)
class AccountControllerTest {

    @Autowired
    private MockMvc mockMvc;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @MockitoBean
    private AccountService accountService;

    @MockitoBean
    private TransactionService transactionService;

    @MockitoBean
    private JwtUtil jwtUtil;

    @MockitoBean
    private JwtAuthFilter jwtAuthFilter;

    @Test
    @DisplayName("Should create an account successfully")
    void shouldCreateAccountSuccessfully() throws Exception {
        // Arrange
        Account account = new Account();
        account.setAccountNumber("ACC001");
        account.setAccountType("SAVINGS");
        account.setBalance(new BigDecimal("1000.00"));

        Account savedAccount = new Account();
        savedAccount.setId(1L);
        savedAccount.setAccountNumber("ACC001");
        savedAccount.setAccountType("SAVINGS");
        savedAccount.setBalance(new BigDecimal("1000.00"));

        when(accountService.createAccount(any(Account.class))).thenReturn(savedAccount);

        // Act & Assert
        mockMvc.perform(post("/api/accounts")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(account)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.accountNumber").value("ACC001"))
                .andExpect(jsonPath("$.accountType").value("SAVINGS"));
    }

    @Test
    @DisplayName("Should get all accounts and return 200")
    void shouldGetAllAccounts() throws Exception {
        // Arrange
        Account account1 = new Account();
        account1.setId(1L);
        account1.setAccountNumber("ACC001");
        account1.setAccountType("SAVINGS");
        account1.setBalance(new BigDecimal("1000.00"));

        Account account2 = new Account();
        account2.setId(2L);
        account2.setAccountNumber("ACC002");
        account2.setAccountType("CURRENT");
        account2.setBalance(new BigDecimal("2000.00"));

        List<Account> accounts = Arrays.asList(account1, account2);
        when(accountService.getAllAccounts()).thenReturn(accounts);

        // Act & Assert
        mockMvc.perform(get("/api/accounts"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].accountNumber").value("ACC001"))
                .andExpect(jsonPath("$[1].accountNumber").value("ACC002"));
    }

    @Test
    @DisplayName("Should get account by ID and return 200")
    void shouldGetAccountById() throws Exception {
        // Arrange
        Account account = new Account();
        account.setId(1L);
        account.setAccountNumber("ACC001");
        account.setAccountType("SAVINGS");
        account.setBalance(new BigDecimal("1000.00"));

        when(accountService.getAccountById(1L)).thenReturn(account);

        // Act & Assert
        mockMvc.perform(get("/api/accounts/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.accountNumber").value("ACC001"));
    }

    @Test
    @DisplayName("Should return 404 when account is not found")
    void shouldReturn404WhenAccountNotFound() throws Exception {
        // Arrange
        when(accountService.getAccountById(99L))
                .thenThrow(new AccountNotFoundException("Account not found with id: 99"));

        // Act & Assert
        mockMvc.perform(get("/api/accounts/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("Should update account successfully and return 200")
    void shouldUpdateAccount() throws Exception {
        // Arrange
        Account updatedAccount = new Account();
        updatedAccount.setId(1L);
        updatedAccount.setAccountNumber("ACC001");
        updatedAccount.setAccountType("CURRENT");
        updatedAccount.setBalance(new BigDecimal("1500.00"));

        when(accountService.updateAccount(eq(1L), any(Account.class))).thenReturn(updatedAccount);

        // Act & Assert
        mockMvc.perform(put("/api/accounts/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updatedAccount)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.accountType").value("CURRENT"))
                .andExpect(jsonPath("$.balance").value(1500.00));
    }

    @Test
    @DisplayName("Should delete account and return 204")
    void shouldDeleteAccount() throws Exception {
        // Arrange
        doNothing().when(accountService).deleteAccount(1L);

        // Act & Assert
        mockMvc.perform(delete("/api/accounts/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    @DisplayName("Should deposit successfully and return updated account")
    void shouldDepositSuccessfully() throws Exception {
        // Arrange
        DepositRequest depositRequest = new DepositRequest(1L, new BigDecimal("500.00"));

        Account updatedAccount = new Account();
        updatedAccount.setId(1L);
        updatedAccount.setAccountNumber("ACC001");
        updatedAccount.setAccountType("SAVINGS");
        updatedAccount.setBalance(new BigDecimal("1500.00"));

        when(accountService.deposit(any(DepositRequest.class))).thenReturn(updatedAccount);

        // Act & Assert
        mockMvc.perform(post("/api/accounts/deposit")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(depositRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.balance").value(1500.00));
    }

    @Test
    @DisplayName("Should withdraw successfully and return updated account")
    void shouldWithdrawSuccessfully() throws Exception {
        // Arrange
        WithdrawRequest withdrawRequest = new WithdrawRequest(1L, new BigDecimal("200.00"));

        Account updatedAccount = new Account();
        updatedAccount.setId(1L);
        updatedAccount.setAccountNumber("ACC001");
        updatedAccount.setAccountType("SAVINGS");
        updatedAccount.setBalance(new BigDecimal("800.00"));

        when(accountService.withdraw(any(WithdrawRequest.class))).thenReturn(updatedAccount);

        // Act & Assert
        mockMvc.perform(post("/api/accounts/withdraw")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(withdrawRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.balance").value(800.00));
    }

    @Test
    @DisplayName("Should return 400 when insufficient balance for withdrawal")
    void shouldReturn400WhenInsufficientBalance() throws Exception {
        // Arrange
        WithdrawRequest withdrawRequest = new WithdrawRequest(1L, new BigDecimal("5000.00"));

        when(accountService.withdraw(any(WithdrawRequest.class)))
                .thenThrow(new ValidationException("Insufficient balance for withdrawal"));

        // Act & Assert
        mockMvc.perform(post("/api/accounts/withdraw")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(withdrawRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("Should transfer successfully and return 200")
    void shouldTransferSuccessfully() throws Exception {
        // Arrange
        TransferRequest transferRequest = new TransferRequest(1L, 2L, new BigDecimal("300.00"));

        doNothing().when(accountService).transfer(any(TransferRequest.class));

        // Act & Assert
        mockMvc.perform(post("/api/accounts/transfer")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(transferRequest)))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("Should get account transactions and return 200")
    void shouldGetAccountTransactions() throws Exception {
        // Arrange
        Transaction txn1 = new Transaction();
        txn1.setId(1L);
        txn1.setTransactionType("DEPOSIT");
        txn1.setAmount(new BigDecimal("500.00"));
        txn1.setTransactionDate(LocalDateTime.now());
        txn1.setDescription("Deposit to account");

        Transaction txn2 = new Transaction();
        txn2.setId(2L);
        txn2.setTransactionType("WITHDRAWAL");
        txn2.setAmount(new BigDecimal("200.00"));
        txn2.setTransactionDate(LocalDateTime.now());
        txn2.setDescription("Withdrawal from account");

        List<Transaction> transactions = Arrays.asList(txn1, txn2);
        when(transactionService.getTransactionsByAccountId(1L)).thenReturn(transactions);

        // Act & Assert
        mockMvc.perform(get("/api/accounts/1/transactions"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].transactionType").value("DEPOSIT"))
                .andExpect(jsonPath("$[1].transactionType").value("WITHDRAWAL"));
    }
}
