package com.northernarc.codingassessment5.controller;

import com.northernarc.codingassessment5.model.Transaction;
import com.northernarc.codingassessment5.security.JwtAuthFilter;
import com.northernarc.codingassessment5.security.JwtUtil;
import com.northernarc.codingassessment5.service.TransactionService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(TransactionController.class)
@AutoConfigureMockMvc(addFilters = false)
class TransactionControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private TransactionService transactionService;

    @MockitoBean
    private JwtUtil jwtUtil;

    @MockitoBean
    private JwtAuthFilter jwtAuthFilter;

    @Test
    @DisplayName("Should get all transactions and return 200")
    void shouldGetAllTransactions() throws Exception {
        // Arrange
        Transaction txn1 = new Transaction();
        txn1.setId(1L);
        txn1.setTransactionType("DEPOSIT");
        txn1.setAmount(new BigDecimal("500.00"));
        txn1.setTransactionDate(LocalDateTime.now());
        txn1.setDescription("Deposit");

        Transaction txn2 = new Transaction();
        txn2.setId(2L);
        txn2.setTransactionType("WITHDRAWAL");
        txn2.setAmount(new BigDecimal("200.00"));
        txn2.setTransactionDate(LocalDateTime.now());
        txn2.setDescription("Withdrawal");

        List<Transaction> transactions = Arrays.asList(txn1, txn2);
        when(transactionService.getAllTransactions()).thenReturn(transactions);

        // Act & Assert
        mockMvc.perform(get("/api/transactions"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].transactionType").value("DEPOSIT"))
                .andExpect(jsonPath("$[1].transactionType").value("WITHDRAWAL"));
    }

    @Test
    @DisplayName("Should get transaction by ID and return 200")
    void shouldGetTransactionById() throws Exception {
        // Arrange
        Transaction transaction = new Transaction();
        transaction.setId(1L);
        transaction.setTransactionType("DEPOSIT");
        transaction.setAmount(new BigDecimal("500.00"));
        transaction.setTransactionDate(LocalDateTime.now());
        transaction.setDescription("Deposit to savings");

        when(transactionService.getTransactionById(1L)).thenReturn(transaction);

        // Act & Assert
        mockMvc.perform(get("/api/transactions/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.transactionType").value("DEPOSIT"))
                .andExpect(jsonPath("$.amount").value(500.00));
    }
}
