package com.northernarc.codingassessment5.exception;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class GlobalExceptionHandlerTest {

    private final GlobalExceptionHandler exceptionHandler = new GlobalExceptionHandler();

    @Test
    @DisplayName("Should return 404 Not Found for CustomerNotFoundException")
    void shouldReturnNotFoundForCustomerNotFoundException() {
        // Arrange
        CustomerNotFoundException exception = new CustomerNotFoundException("Customer not found");

        // Act
        ResponseEntity<String> response = exceptionHandler.handleCustomerNotFound(exception);

        // Assert
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("Customer not found", response.getBody());
    }

    @Test
    @DisplayName("Should return 404 Not Found for AccountNotFoundException")
    void shouldReturnNotFoundForAccountNotFoundException() {
        // Arrange
        AccountNotFoundException exception = new AccountNotFoundException("Account not found");

        // Act
        ResponseEntity<String> response = exceptionHandler.handleAccountNotFound(exception);

        // Assert
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("Account not found", response.getBody());
    }

    @Test
    @DisplayName("Should return 409 Conflict for DuplicateEmailException")
    void shouldReturnConflictForDuplicateEmailException() {
        // Arrange
        DuplicateEmailException exception = new DuplicateEmailException("Email already exists");

        // Act
        ResponseEntity<String> response = exceptionHandler.handleDuplicateEmail(exception);

        // Assert
        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
        assertEquals("Email already exists", response.getBody());
    }

    @Test
    @DisplayName("Should return 400 Bad Request for ValidationException")
    void shouldReturnBadRequestForValidationException() {
        // Arrange
        ValidationException exception = new ValidationException("Validation failed");

        // Act
        ResponseEntity<String> response = exceptionHandler.handleValidation(exception);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Validation failed", response.getBody());
    }
}
