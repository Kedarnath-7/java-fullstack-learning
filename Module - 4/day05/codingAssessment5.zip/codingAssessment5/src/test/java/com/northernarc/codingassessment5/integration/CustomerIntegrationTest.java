package com.northernarc.codingassessment5.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.northernarc.codingassessment5.model.Customer;
import com.northernarc.codingassessment5.repository.CustomerRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.transaction.annotation.Transactional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
@Transactional
class CustomerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    private CustomerRepository customerRepository;

    @Test
    @DisplayName("Should create and retrieve a customer end-to-end")
    void shouldCreateAndRetrieveCustomer() throws Exception {
        // Arrange
        Customer customer = new Customer();
        customer.setName("John Doe");
        customer.setEmail("john.integration@example.com");
        customer.setPhone("1234567890");
        customer.setPassword("password123");

        // Act - Create customer
        MvcResult createResult = mockMvc.perform(post("/api/customers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(customer)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").exists())
                .andExpect(jsonPath("$.name").value("John Doe"))
                .andReturn();

        // Extract created customer ID
        String responseJson = createResult.getResponse().getContentAsString();
        Customer createdCustomer = objectMapper.readValue(responseJson, Customer.class);
        Long customerId = createdCustomer.getId();

        // Assert - Retrieve customer
        mockMvc.perform(get("/api/customers/" + customerId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("John Doe"))
                .andExpect(jsonPath("$.email").value("john.integration@example.com"));
    }

    @Test
    @DisplayName("Should return 409 when creating customer with duplicate email")
    void shouldReturn409WhenCreatingDuplicateEmailCustomer() throws Exception {
        // Arrange
        Customer customer = new Customer();
        customer.setName("John Doe");
        customer.setEmail("duplicate@example.com");
        customer.setPhone("1234567890");
        customer.setPassword("password123");

        // Act - Create first customer
        mockMvc.perform(post("/api/customers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(customer)))
                .andExpect(status().isCreated());

        // Act & Assert - Create second customer with same email
        Customer duplicateCustomer = new Customer();
        duplicateCustomer.setName("Jane Doe");
        duplicateCustomer.setEmail("duplicate@example.com");
        duplicateCustomer.setPhone("0987654321");
        duplicateCustomer.setPassword("password456");

        mockMvc.perform(post("/api/customers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(duplicateCustomer)))
                .andExpect(status().isConflict());
    }

    @Test
    @DisplayName("Should update an existing customer")
    void shouldUpdateExistingCustomer() throws Exception {
        // Arrange - Create customer
        Customer customer = new Customer();
        customer.setName("John Doe");
        customer.setEmail("john.update@example.com");
        customer.setPhone("1234567890");
        customer.setPassword("password123");

        MvcResult createResult = mockMvc.perform(post("/api/customers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(customer)))
                .andExpect(status().isCreated())
                .andReturn();

        Customer createdCustomer = objectMapper.readValue(
                createResult.getResponse().getContentAsString(), Customer.class);
        Long customerId = createdCustomer.getId();

        // Act - Update customer
        Customer updatedCustomer = new Customer();
        updatedCustomer.setName("John Updated");
        updatedCustomer.setEmail("john.update@example.com");
        updatedCustomer.setPhone("9876543210");
        updatedCustomer.setPassword("newpassword123");

        mockMvc.perform(put("/api/customers/" + customerId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updatedCustomer)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("John Updated"));

        // Assert - Verify update
        mockMvc.perform(get("/api/customers/" + customerId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("John Updated"))
                .andExpect(jsonPath("$.phone").value("9876543210"));
    }

    @Test
    @DisplayName("Should delete an existing customer and return 404 on subsequent GET")
    void shouldDeleteExistingCustomer() throws Exception {
        // Arrange - Create customer
        Customer customer = new Customer();
        customer.setName("John Doe");
        customer.setEmail("john.delete@example.com");
        customer.setPhone("1234567890");
        customer.setPassword("password123");

        MvcResult createResult = mockMvc.perform(post("/api/customers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(customer)))
                .andExpect(status().isCreated())
                .andReturn();

        Customer createdCustomer = objectMapper.readValue(
                createResult.getResponse().getContentAsString(), Customer.class);
        Long customerId = createdCustomer.getId();

        // Act - Delete customer
        mockMvc.perform(delete("/api/customers/" + customerId))
                .andExpect(status().isNoContent());

        // Assert - Verify deletion
        mockMvc.perform(get("/api/customers/" + customerId))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("Should return 400 when customer name is blank")
    void shouldValidateMandatoryCustomerName() throws Exception {
        // Arrange
        Customer customer = new Customer();
        customer.setName("");
        customer.setEmail("noname@example.com");
        customer.setPhone("1234567890");
        customer.setPassword("password123");

        // Act & Assert
        mockMvc.perform(post("/api/customers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(customer)))
                .andExpect(status().isBadRequest());
    }
}
