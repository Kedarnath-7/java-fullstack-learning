package com.northernarc.codingassessment5.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.northernarc.codingassessment5.dto.TransferRequest;
import com.northernarc.codingassessment5.model.Account;
import com.northernarc.codingassessment5.model.Customer;
import com.northernarc.codingassessment5.repository.AccountRepository;
import com.northernarc.codingassessment5.repository.CustomerRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
@Transactional
class TransferIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private CustomerRepository customerRepository;

    private Long sourceAccountId;
    private Long destinationAccountId;

    @BeforeEach
    void setUp() throws Exception {
        // Create a customer
        Customer customer = new Customer();
        customer.setName("Transfer Test User");
        customer.setEmail("transfer@example.com");
        customer.setPhone("1234567890");
        customer.setPassword("password123");

        Customer savedCustomer = customerRepository.save(customer);

        // Create source account
        Account sourceAccount = new Account();
        sourceAccount.setAccountNumber("SRC001");
        sourceAccount.setAccountType("SAVINGS");
        sourceAccount.setBalance(new BigDecimal("5000.00"));
        sourceAccount.setCustomer(savedCustomer);
        Account savedSource = accountRepository.save(sourceAccount);
        sourceAccountId = savedSource.getId();

        // Create destination account
        Account destAccount = new Account();
        destAccount.setAccountNumber("DST001");
        destAccount.setAccountType("SAVINGS");
        destAccount.setBalance(new BigDecimal("1000.00"));
        destAccount.setCustomer(savedCustomer);
        Account savedDest = accountRepository.save(destAccount);
        destinationAccountId = savedDest.getId();
    }

    @Test
    @DisplayName("Should transfer between accounts successfully and update balances")
    void shouldTransferBetweenAccountsSuccessfully() throws Exception {
        // Arrange
        TransferRequest transferRequest = new TransferRequest(sourceAccountId, destinationAccountId, new BigDecimal("1000.00"));

        // Act
        mockMvc.perform(post("/api/accounts/transfer")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(transferRequest)))
                .andExpect(status().isOk());

        // Assert - Verify source account balance decreased
        mockMvc.perform(get("/api/accounts/" + sourceAccountId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.balance").value(4000.00));

        // Assert - Verify destination account balance increased
        mockMvc.perform(get("/api/accounts/" + destinationAccountId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.balance").value(2000.00));
    }

    @Test
    @DisplayName("Should return 400 when transferring to the same account")
    void shouldReturn400WhenTransferToSameAccount() throws Exception {
        // Arrange
        TransferRequest transferRequest = new TransferRequest(sourceAccountId, sourceAccountId, new BigDecimal("500.00"));

        // Act & Assert
        mockMvc.perform(post("/api/accounts/transfer")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(transferRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("Should return 400 when insufficient balance for transfer")
    void shouldReturn400WhenInsufficientBalanceForTransfer() throws Exception {
        // Arrange
        TransferRequest transferRequest = new TransferRequest(sourceAccountId, destinationAccountId, new BigDecimal("99999.00"));

        // Act & Assert
        mockMvc.perform(post("/api/accounts/transfer")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(transferRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("Should return 404 when source account does not exist")
    void shouldReturn404WhenSourceAccountNotFound() throws Exception {
        // Arrange
        TransferRequest transferRequest = new TransferRequest(99999L, destinationAccountId, new BigDecimal("100.00"));

        // Act & Assert
        mockMvc.perform(post("/api/accounts/transfer")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(transferRequest)))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("Should return 404 when destination account does not exist")
    void shouldReturn404WhenDestinationAccountNotFound() throws Exception {
        // Arrange
        TransferRequest transferRequest = new TransferRequest(sourceAccountId, 99999L, new BigDecimal("100.00"));

        // Act & Assert
        mockMvc.perform(post("/api/accounts/transfer")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(transferRequest)))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("Should create two transaction records on successful transfer")
    void shouldCreateTwoTransactionRecordsOnTransfer() throws Exception {
        // Arrange
        TransferRequest transferRequest = new TransferRequest(sourceAccountId, destinationAccountId, new BigDecimal("500.00"));

        // Act
        mockMvc.perform(post("/api/accounts/transfer")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(transferRequest)))
                .andExpect(status().isOk());

        // Assert - Source account should have a debit transaction
        mockMvc.perform(get("/api/accounts/" + sourceAccountId + "/transactions"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(org.hamcrest.Matchers.greaterThanOrEqualTo(1)));

        // Assert - Destination account should have a credit transaction
        mockMvc.perform(get("/api/accounts/" + destinationAccountId + "/transactions"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(org.hamcrest.Matchers.greaterThanOrEqualTo(1)));
    }
}
