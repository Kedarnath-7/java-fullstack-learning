package com.northernarc.codingassessment5.repository;

import com.northernarc.codingassessment5.model.Account;
import com.northernarc.codingassessment5.model.Customer;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;
import org.springframework.boot.jdbc.test.autoconfigure.AutoConfigureTestDatabase;
import org.springframework.boot.jpa.test.autoconfigure.TestEntityManager;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
class AccountRepositoryTest {

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private TestEntityManager entityManager;

    private Customer persistTestCustomer(String email) {
        Customer customer = new Customer(null, "Test User", email, "1234567890", "testPassword", null);
        return entityManager.persist(customer);
    }

    @Test
    @DisplayName("Should save account")
    void shouldSaveAccount() {
        // Arrange
        Customer customer = persistTestCustomer("john@example.com");
        entityManager.flush();
        Account account = new Account(null, "ACC001", "SAVINGS", new BigDecimal("1000.00"), customer, null);

        // Act
        Account saved = accountRepository.save(account);

        // Assert
        assertNotNull(saved.getId());
        assertEquals("ACC001", saved.getAccountNumber());
        assertEquals("SAVINGS", saved.getAccountType());
    }

    @Test
    @DisplayName("Should find account by account number")
    void shouldFindAccountByAccountNumber() {
        // Arrange
        Customer customer = persistTestCustomer("john@example.com");
        Account account = new Account(null, "ACC001", "SAVINGS", new BigDecimal("1000.00"), customer, null);
        entityManager.persist(account);
        entityManager.flush();

        // Act
        Optional<Account> found = accountRepository.findByAccountNumber("ACC001");

        // Assert
        assertTrue(found.isPresent());
        assertEquals("ACC001", found.get().getAccountNumber());
    }

    @Test
    @DisplayName("Should return empty when account number not found")
    void shouldReturnEmptyWhenAccountNumberNotFound() {
        // Act
        Optional<Account> found = accountRepository.findByAccountNumber("NONEXISTENT");

        // Assert
        assertFalse(found.isPresent());
    }

    @Test
    @DisplayName("Should check if account number exists")
    void shouldCheckIfAccountNumberExists() {
        // Arrange
        Customer customer = persistTestCustomer("john@example.com");
        Account account = new Account(null, "ACC001", "SAVINGS", new BigDecimal("1000.00"), customer, null);
        entityManager.persist(account);
        entityManager.flush();

        // Act & Assert
        assertTrue(accountRepository.existsByAccountNumber("ACC001"));
        assertFalse(accountRepository.existsByAccountNumber("NONEXISTENT"));
    }

    @Test
    @DisplayName("Should find accounts by customer ID")
    void shouldFindAccountsByCustomerId() {
        // Arrange
        Customer customer = persistTestCustomer("john@example.com");
        Account account1 = new Account(null, "ACC001", "SAVINGS", new BigDecimal("1000.00"), customer, null);
        Account account2 = new Account(null, "ACC002", "CURRENT", new BigDecimal("2000.00"), customer, null);
        entityManager.persist(account1);
        entityManager.persist(account2);
        entityManager.flush();

        // Act
        List<Account> accounts = accountRepository.findByCustomerId(customer.getId());

        // Assert
        assertNotNull(accounts);
        assertEquals(2, accounts.size());
    }

    @Test
    @DisplayName("Should delete account")
    void shouldDeleteAccount() {
        // Arrange
        Customer customer = persistTestCustomer("john@example.com");
        Account account = new Account(null, "ACC001", "SAVINGS", new BigDecimal("1000.00"), customer, null);
        Account persisted = entityManager.persist(account);
        entityManager.flush();
        Long id = persisted.getId();

        // Act
        accountRepository.deleteById(id);
        entityManager.flush();

        // Assert
        Optional<Account> found = accountRepository.findById(id);
        assertFalse(found.isPresent());
    }

    @Test
    @DisplayName("Should enforce unique account number constraint")
    void shouldEnforceUniqueAccountNumber() {
        // Arrange
        Customer customer = persistTestCustomer("john@example.com");
        Account account1 = new Account(null, "ACC001", "SAVINGS", new BigDecimal("1000.00"), customer, null);
        entityManager.persist(account1);
        entityManager.flush();

        // Act & Assert
        Account account2 = new Account(null, "ACC001", "CURRENT", new BigDecimal("2000.00"), customer, null);
        assertThrows(Exception.class, () -> {
            entityManager.persist(account2);
            entityManager.flush();
        });
    }
}
