package com.northernarc.codingassessment5.repository;

import com.northernarc.codingassessment5.model.Customer;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;
import org.springframework.boot.jdbc.test.autoconfigure.AutoConfigureTestDatabase;
import org.springframework.boot.jpa.test.autoconfigure.TestEntityManager;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
class CustomerRepositoryTest {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private TestEntityManager entityManager;

    private Customer createTestCustomer(String name, String email, String phone) {
        return new Customer(null, name, email, phone, "testPassword123", null);
    }

    @Test
    @DisplayName("Should save customer")
    void shouldSaveCustomer() {
        // Arrange
        Customer customer = createTestCustomer("John Doe", "john@example.com", "1234567890");

        // Act
        Customer saved = customerRepository.save(customer);

        // Assert
        assertNotNull(saved.getId());
        assertEquals("John Doe", saved.getName());
        assertEquals("john@example.com", saved.getEmail());
    }

    @Test
    @DisplayName("Should find customer by email")
    void shouldFindCustomerByEmail() {
        // Arrange
        Customer customer = createTestCustomer("John Doe", "john@example.com", "1234567890");
        entityManager.persist(customer);
        entityManager.flush();

        // Act
        Optional<Customer> found = customerRepository.findByEmail("john@example.com");

        // Assert
        assertTrue(found.isPresent());
        assertEquals("John Doe", found.get().getName());
    }

    @Test
    @DisplayName("Should return empty when email not found")
    void shouldReturnEmptyWhenEmailNotFound() {
        // Act
        Optional<Customer> found = customerRepository.findByEmail("nonexistent@example.com");

        // Assert
        assertFalse(found.isPresent());
    }

    @Test
    @DisplayName("Should check if email exists")
    void shouldCheckIfEmailExists() {
        // Arrange
        Customer customer = createTestCustomer("John Doe", "john@example.com", "1234567890");
        entityManager.persist(customer);
        entityManager.flush();

        // Act & Assert
        assertTrue(customerRepository.existsByEmail("john@example.com"));
        assertFalse(customerRepository.existsByEmail("nonexistent@example.com"));
    }

    @Test
    @DisplayName("Should find customer by ID")
    void shouldFindCustomerById() {
        // Arrange
        Customer customer = createTestCustomer("John Doe", "john@example.com", "1234567890");
        Customer persisted = entityManager.persist(customer);
        entityManager.flush();

        // Act
        Optional<Customer> found = customerRepository.findById(persisted.getId());

        // Assert
        assertTrue(found.isPresent());
        assertEquals("John Doe", found.get().getName());
    }

    @Test
    @DisplayName("Should delete customer")
    void shouldDeleteCustomer() {
        // Arrange
        Customer customer = createTestCustomer("John Doe", "john@example.com", "1234567890");
        Customer persisted = entityManager.persist(customer);
        entityManager.flush();
        Long id = persisted.getId();

        // Act
        customerRepository.deleteById(id);
        entityManager.flush();

        // Assert
        Optional<Customer> found = customerRepository.findById(id);
        assertFalse(found.isPresent());
    }

    @Test
    @DisplayName("Should enforce unique email constraint")
    void shouldEnforceUniqueEmail() {
        // Arrange
        Customer customer1 = createTestCustomer("John Doe", "duplicate@example.com", "1234567890");
        entityManager.persist(customer1);
        entityManager.flush();

        // Act & Assert
        Customer customer2 = createTestCustomer("Jane Doe", "duplicate@example.com", "0987654321");
        assertThrows(Exception.class, () -> {
            entityManager.persist(customer2);
            entityManager.flush();
        });
    }
}
