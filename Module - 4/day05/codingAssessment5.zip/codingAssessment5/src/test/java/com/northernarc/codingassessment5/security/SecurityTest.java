package com.northernarc.codingassessment5.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.northernarc.codingassessment5.dto.LoginRequest;
import com.northernarc.codingassessment5.dto.RegisterRequest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class SecurityTest {

    @Autowired
    private MockMvc mockMvc;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    @DisplayName("Should allow access to /api/auth/register without authentication")
    void shouldAllowAccessToRegisterWithoutAuth() throws Exception {
        // Arrange
        RegisterRequest request = new RegisterRequest("John Doe", "john@example.com", "1234567890", "password123");

        // Act
        int status = mockMvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andReturn().getResponse().getStatus();

        // Assert
        assertNotEquals(401, status, "Register endpoint should not return 401 Unauthorized");
    }

    @Test
    @DisplayName("Should allow access to /api/auth/login without authentication")
    void shouldAllowAccessToLoginWithoutAuth() throws Exception {
        // Arrange
        LoginRequest request = new LoginRequest("john@example.com", "password123");

        // Act
        int status = mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andReturn().getResponse().getStatus();

        // Assert
        assertNotEquals(401, status, "Login endpoint should not return 401 Unauthorized");
    }

    @Test
    @DisplayName("Should return 401 when no JWT token is provided")
    void shouldReturn401WhenNoJwtProvided() throws Exception {
        // Act & Assert
        mockMvc.perform(get("/api/customers"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("Should return 401 when invalid JWT token is provided")
    void shouldReturn401WhenInvalidJwtProvided() throws Exception {
        // Act & Assert
        mockMvc.perform(get("/api/customers")
                        .header("Authorization", "Bearer invalid.jwt.token"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("Should return 401 when expired JWT token is provided")
    void shouldReturn401WhenExpiredJwtProvided() throws Exception {
        // Arrange
        String expiredToken = "Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ0ZXN0QGV4YW1wbGUuY29tIiwiaWF0IjoxNjAwMDAwMDAwLCJleHAiOjE2MDAwMDAwMDF9.invalid";

        // Act & Assert
        mockMvc.perform(get("/api/customers")
                        .header("Authorization", expiredToken))
                .andExpect(status().isUnauthorized());
    }
}
