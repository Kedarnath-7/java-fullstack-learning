package com.northernarc.codingassessment5.service;

import com.northernarc.codingassessment5.dto.DepositRequest;
import com.northernarc.codingassessment5.dto.TransferRequest;
import com.northernarc.codingassessment5.dto.WithdrawRequest;
import com.northernarc.codingassessment5.exception.AccountNotFoundException;
import com.northernarc.codingassessment5.exception.ValidationException;
import com.northernarc.codingassessment5.model.Account;
import com.northernarc.codingassessment5.model.Customer;
import com.northernarc.codingassessment5.model.Transaction;
import com.northernarc.codingassessment5.repository.AccountRepository;
import com.northernarc.codingassessment5.repository.TransactionRepository;
import com.northernarc.codingassessment5.service.impl.AccountServiceImpl;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AccountServiceTest {

    @Mock
    private AccountRepository accountRepository;

    @Mock
    private TransactionRepository transactionRepository;

    @InjectMocks
    private AccountServiceImpl accountService;

    private Customer createTestCustomer() {
        return new Customer(1L, "John Doe", "john@example.com", "1234567890", "pass", null);
    }

    private Account createTestAccount() {
        return new Account(1L, "ACC001", "SAVINGS", new BigDecimal("1000.00"), createTestCustomer(), null);
    }

    @Test
    @DisplayName("Should create account successfully")
    void shouldCreateAccountSuccessfully() {
        // Arrange
        Account account = new Account(null, "ACC001", "SAVINGS", new BigDecimal("500.00"), createTestCustomer(), null);
        Account savedAccount = new Account(1L, "ACC001", "SAVINGS", new BigDecimal("500.00"), createTestCustomer(), null);
        when(accountRepository.save(any(Account.class))).thenReturn(savedAccount);

        // Act
        Account result = accountService.createAccount(account);

        // Assert
        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("ACC001", result.getAccountNumber());
        verify(accountRepository).save(any(Account.class));
    }

    @Test
    @DisplayName("Should not allow negative opening balance")
    void shouldNotAllowNegativeOpeningBalance() {
        // Arrange
        Account account = new Account(null, "ACC001", "SAVINGS", new BigDecimal("-100.00"), createTestCustomer(), null);

        // Act & Assert
        assertThrows(ValidationException.class, () -> accountService.createAccount(account));
        verify(accountRepository, never()).save(any(Account.class));
    }

    @Test
    @DisplayName("Should get all accounts")
    void shouldGetAllAccounts() {
        // Arrange
        List<Account> accounts = Arrays.asList(
                new Account(1L, "ACC001", "SAVINGS", new BigDecimal("1000.00"), createTestCustomer(), null),
                new Account(2L, "ACC002", "CURRENT", new BigDecimal("2000.00"), createTestCustomer(), null)
        );
        when(accountRepository.findAll()).thenReturn(accounts);

        // Act
        List<Account> result = accountService.getAllAccounts();

        // Assert
        assertNotNull(result);
        assertEquals(2, result.size());
        verify(accountRepository).findAll();
    }

    @Test
    @DisplayName("Should get account by ID")
    void shouldGetAccountById() {
        // Arrange
        Account account = createTestAccount();
        when(accountRepository.findById(1L)).thenReturn(Optional.of(account));

        // Act
        Account result = accountService.getAccountById(1L);

        // Assert
        assertNotNull(result);
        assertEquals(1L, result.getId());
    }

    @Test
    @DisplayName("Should throw AccountNotFoundException when ID not found")
    void shouldThrowAccountNotFoundExceptionWhenIdNotFound() {
        // Arrange
        when(accountRepository.findById(99L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(AccountNotFoundException.class, () -> accountService.getAccountById(99L));
    }

    @Test
    @DisplayName("Should update account successfully")
    void shouldUpdateAccountSuccessfully() {
        // Arrange
        Account existingAccount = createTestAccount();
        Account updatedAccount = new Account(1L, "ACC001", "CURRENT", new BigDecimal("1500.00"), createTestCustomer(), null);
        when(accountRepository.findById(1L)).thenReturn(Optional.of(existingAccount));
        when(accountRepository.save(any(Account.class))).thenReturn(updatedAccount);

        // Act
        Account result = accountService.updateAccount(1L, updatedAccount);

        // Assert
        assertNotNull(result);
        assertEquals("CURRENT", result.getAccountType());
        verify(accountRepository).save(any(Account.class));
    }

    @Test
    @DisplayName("Should delete account successfully")
    void shouldDeleteAccountSuccessfully() {
        // Arrange
        Account account = createTestAccount();
        when(accountRepository.findById(1L)).thenReturn(Optional.of(account));
        doNothing().when(accountRepository).deleteById(1L);

        // Act
        accountService.deleteAccount(1L);

        // Assert
        verify(accountRepository).deleteById(1L);
    }

    @Test
    @DisplayName("Should deposit successfully and increase balance")
    void shouldDepositSuccessfully() {
        // Arrange
        Account account = new Account(1L, "ACC001", "SAVINGS", new BigDecimal("1000.00"), createTestCustomer(), null);
        DepositRequest request = new DepositRequest(1L, new BigDecimal("500.00"));
        when(accountRepository.findById(1L)).thenReturn(Optional.of(account));
        when(accountRepository.save(any(Account.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(transactionRepository.save(any(Transaction.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        Account result = accountService.deposit(request);

        // Assert
        assertNotNull(result);
        assertEquals(new BigDecimal("1500.00"), result.getBalance());
    }

    @Test
    @DisplayName("Should throw exception when deposit amount is zero or negative")
    void shouldThrowExceptionWhenDepositAmountIsZeroOrNegative() {
        // Arrange
        DepositRequest request = new DepositRequest(1L, new BigDecimal("-50.00"));

        // Act & Assert
        assertThrows(ValidationException.class, () -> accountService.deposit(request));
        verify(accountRepository, never()).findById(any());
        verify(accountRepository, never()).save(any(Account.class));
        verify(transactionRepository, never()).save(any(Transaction.class));
    }

    @Test
    @DisplayName("Should throw AccountNotFoundException on deposit when account does not exist")
    void shouldThrowAccountNotFoundOnDepositWhenAccountDoesNotExist() {
        // Arrange
        DepositRequest request = new DepositRequest(99L, new BigDecimal("500.00"));
        when(accountRepository.findById(99L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(AccountNotFoundException.class, () -> accountService.deposit(request));
    }

    @Test
    @DisplayName("Should create transaction record on deposit")
    void shouldCreateTransactionRecordOnDeposit() {
        // Arrange
        Account account = new Account(1L, "ACC001", "SAVINGS", new BigDecimal("1000.00"), createTestCustomer(), null);
        DepositRequest request = new DepositRequest(1L, new BigDecimal("500.00"));
        when(accountRepository.findById(1L)).thenReturn(Optional.of(account));
        when(accountRepository.save(any(Account.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(transactionRepository.save(any(Transaction.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        accountService.deposit(request);

        // Assert
        verify(transactionRepository).save(any(Transaction.class));
    }

    @Test
    @DisplayName("Should withdraw successfully")
    void shouldWithdrawSuccessfully() {
        // Arrange
        Account account = new Account(1L, "ACC001", "SAVINGS", new BigDecimal("1000.00"), createTestCustomer(), null);
        WithdrawRequest request = new WithdrawRequest(1L, new BigDecimal("300.00"));
        when(accountRepository.findById(1L)).thenReturn(Optional.of(account));
        when(accountRepository.save(any(Account.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(transactionRepository.save(any(Transaction.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        Account result = accountService.withdraw(request);

        // Assert
        assertNotNull(result);
        assertEquals(new BigDecimal("700.00"), result.getBalance());
    }

    @Test
    @DisplayName("Should throw exception when withdrawal exceeds balance")
    void shouldThrowExceptionWhenWithdrawalExceedsBalance() {
        // Arrange
        Account account = new Account(1L, "ACC001", "SAVINGS", new BigDecimal("100.00"), createTestCustomer(), null);
        WithdrawRequest request = new WithdrawRequest(1L, new BigDecimal("500.00"));
        when(accountRepository.findById(1L)).thenReturn(Optional.of(account));

        // Act & Assert
        assertThrows(ValidationException.class, () -> accountService.withdraw(request));
    }

    @Test
    @DisplayName("Should throw exception when withdrawal amount is zero or negative")
    void shouldThrowExceptionWhenWithdrawalAmountIsZeroOrNegative() {
        // Arrange
        WithdrawRequest request = new WithdrawRequest(1L, new BigDecimal("0.00"));

        // Act & Assert
        assertThrows(ValidationException.class, () -> accountService.withdraw(request));
        verify(accountRepository, never()).save(any(Account.class));
        verify(transactionRepository, never()).save(any(Transaction.class));
    }

    @Test
    @DisplayName("Should create transaction record on withdrawal")
    void shouldCreateTransactionRecordOnWithdrawal() {
        // Arrange
        Account account = new Account(1L, "ACC001", "SAVINGS", new BigDecimal("1000.00"), createTestCustomer(), null);
        WithdrawRequest request = new WithdrawRequest(1L, new BigDecimal("200.00"));
        when(accountRepository.findById(1L)).thenReturn(Optional.of(account));
        when(accountRepository.save(any(Account.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(transactionRepository.save(any(Transaction.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        accountService.withdraw(request);

        // Assert
        verify(transactionRepository).save(any(Transaction.class));
    }

    @Test
    @DisplayName("Should transfer successfully")
    void shouldTransferSuccessfully() {
        // Arrange
        Account source = new Account(1L, "ACC001", "SAVINGS", new BigDecimal("1000.00"), createTestCustomer(), null);
        Account destination = new Account(2L, "ACC002", "SAVINGS", new BigDecimal("500.00"), createTestCustomer(), null);
        TransferRequest request = new TransferRequest(1L, 2L, new BigDecimal("300.00"));
        when(accountRepository.findById(1L)).thenReturn(Optional.of(source));
        when(accountRepository.findById(2L)).thenReturn(Optional.of(destination));
        when(accountRepository.save(any(Account.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(transactionRepository.save(any(Transaction.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        accountService.transfer(request);

        // Assert
        assertEquals(new BigDecimal("700.00"), source.getBalance());
        assertEquals(new BigDecimal("800.00"), destination.getBalance());
    }

    @Test
    @DisplayName("Should throw exception when source account not found for transfer")
    void shouldThrowExceptionWhenSourceAccountNotFound() {
        // Arrange
        TransferRequest request = new TransferRequest(99L, 2L, new BigDecimal("300.00"));
        when(accountRepository.findById(99L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(AccountNotFoundException.class, () -> accountService.transfer(request));
    }

    @Test
    @DisplayName("Should throw exception when destination account not found for transfer")
    void shouldThrowExceptionWhenDestinationAccountNotFound() {
        // Arrange
        Account source = createTestAccount();
        TransferRequest request = new TransferRequest(1L, 99L, new BigDecimal("300.00"));
        when(accountRepository.findById(1L)).thenReturn(Optional.of(source));
        when(accountRepository.findById(99L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(AccountNotFoundException.class, () -> accountService.transfer(request));
    }

    @Test
    @DisplayName("Should throw exception when source and destination are the same account")
    void shouldThrowExceptionWhenSourceAndDestinationAreSame() {
        // Arrange
        Account account = createTestAccount();
        TransferRequest request = new TransferRequest(1L, 1L, new BigDecimal("300.00"));
        when(accountRepository.findById(1L)).thenReturn(Optional.of(account));

        // Act & Assert
        assertThrows(ValidationException.class, () -> accountService.transfer(request));
    }

    @Test
    @DisplayName("Should throw exception when transfer amount is not positive")
    void shouldThrowExceptionWhenTransferAmountIsNotPositive() {
        // Arrange
        TransferRequest request = new TransferRequest(1L, 2L, new BigDecimal("0.00"));

        // Act & Assert
        assertThrows(ValidationException.class, () -> accountService.transfer(request));
        verify(accountRepository, never()).save(any(Account.class));
        verify(transactionRepository, never()).save(any(Transaction.class));
    }

    @Test
    @DisplayName("Should create two transaction records on transfer")
    void shouldCreateTwoTransactionRecordsOnTransfer() {
        // Arrange
        Account source = new Account(1L, "ACC001", "SAVINGS", new BigDecimal("1000.00"), createTestCustomer(), null);
        Account destination = new Account(2L, "ACC002", "SAVINGS", new BigDecimal("500.00"), createTestCustomer(), null);
        TransferRequest request = new TransferRequest(1L, 2L, new BigDecimal("300.00"));
        when(accountRepository.findById(1L)).thenReturn(Optional.of(source));
        when(accountRepository.findById(2L)).thenReturn(Optional.of(destination));
        when(accountRepository.save(any(Account.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(transactionRepository.save(any(Transaction.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        accountService.transfer(request);

        // Assert
        verify(transactionRepository, times(2)).save(any(Transaction.class));
    }
}
