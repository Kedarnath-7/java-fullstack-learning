package com.northernarc.codingassessment5.service;

import com.northernarc.codingassessment5.exception.CustomerNotFoundException;
import com.northernarc.codingassessment5.exception.DuplicateEmailException;
import com.northernarc.codingassessment5.model.Customer;
import com.northernarc.codingassessment5.repository.CustomerRepository;
import com.northernarc.codingassessment5.service.impl.CustomerServiceImpl;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerServiceTest {

    @Mock
    private CustomerRepository customerRepository;

    @InjectMocks
    private CustomerServiceImpl customerService;

    @Test
    @DisplayName("Should create customer successfully")
    void shouldCreateCustomerSuccessfully() {
        // Arrange
        Customer customer = new Customer(null, "John Doe", "john@example.com", "1234567890", "password123", null);
        Customer savedCustomer = new Customer(1L, "John Doe", "john@example.com", "1234567890", "encryptedPass", null);
        when(customerRepository.existsByEmail("john@example.com")).thenReturn(false);
        when(customerRepository.save(any(Customer.class))).thenReturn(savedCustomer);

        // Act
        Customer result = customerService.createCustomer(customer);

        // Assert
        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("John Doe", result.getName());
        verify(customerRepository).save(any(Customer.class));
    }

    @Test
    @DisplayName("Should throw DuplicateEmailException when email already exists")
    void shouldThrowDuplicateEmailExceptionWhenEmailExists() {
        // Arrange
        Customer customer = new Customer(null, "John Doe", "john@example.com", "1234567890", "password123", null);
        when(customerRepository.existsByEmail("john@example.com")).thenReturn(true);

        // Act & Assert
        assertThrows(DuplicateEmailException.class, () -> customerService.createCustomer(customer));
        verify(customerRepository, never()).save(any(Customer.class));
    }

    @Test
    @DisplayName("Should get all customers")
    void shouldGetAllCustomers() {
        // Arrange
        List<Customer> customers = Arrays.asList(
                new Customer(1L, "John Doe", "john@example.com", "1234567890", "pass1", null),
                new Customer(2L, "Jane Doe", "jane@example.com", "0987654321", "pass2", null)
        );
        when(customerRepository.findAll()).thenReturn(customers);

        // Act
        List<Customer> result = customerService.getAllCustomers();

        // Assert
        assertNotNull(result);
        assertEquals(2, result.size());
        verify(customerRepository).findAll();
    }

    @Test
    @DisplayName("Should get customer by ID")
    void shouldGetCustomerById() {
        // Arrange
        Customer customer = new Customer(1L, "John Doe", "john@example.com", "1234567890", "pass", null);
        when(customerRepository.findById(1L)).thenReturn(Optional.of(customer));

        // Act
        Customer result = customerService.getCustomerById(1L);

        // Assert
        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("John Doe", result.getName());
    }

    @Test
    @DisplayName("Should throw CustomerNotFoundException when ID not found")
    void shouldThrowCustomerNotFoundExceptionWhenIdNotFound() {
        // Arrange
        when(customerRepository.findById(99L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(CustomerNotFoundException.class, () -> customerService.getCustomerById(99L));
    }

    @Test
    @DisplayName("Should update customer successfully")
    void shouldUpdateCustomerSuccessfully() {
        // Arrange
        Customer existingCustomer = new Customer(1L, "John Doe", "john@example.com", "1234567890", "pass", null);
        Customer updatedCustomer = new Customer(1L, "John Updated", "john@example.com", "1234567890", "pass", null);
        when(customerRepository.findById(1L)).thenReturn(Optional.of(existingCustomer));
        when(customerRepository.save(any(Customer.class))).thenReturn(updatedCustomer);

        // Act
        Customer result = customerService.updateCustomer(1L, updatedCustomer);

        // Assert
        assertNotNull(result);
        assertEquals("John Updated", result.getName());
        verify(customerRepository).save(any(Customer.class));
    }

    @Test
    @DisplayName("Should delete customer successfully")
    void shouldDeleteCustomerSuccessfully() {
        // Arrange
        Customer customer = new Customer(1L, "John Doe", "john@example.com", "1234567890", "pass", null);
        when(customerRepository.findById(1L)).thenReturn(Optional.of(customer));
        doNothing().when(customerRepository).deleteById(1L);

        // Act
        customerService.deleteCustomer(1L);

        // Assert
        verify(customerRepository).deleteById(1L);
    }

    @Test
    @DisplayName("Should find customer by email")
    void shouldFindCustomerByEmail() {
        // Arrange
        Customer customer = new Customer(1L, "John Doe", "john@example.com", "1234567890", "pass", null);
        when(customerRepository.findByEmail("john@example.com")).thenReturn(Optional.of(customer));

        // Act
        Customer result = customerService.findByEmail("john@example.com");

        // Assert
        assertNotNull(result);
        assertEquals("john@example.com", result.getEmail());
    }

    @Test
    @DisplayName("Should encrypt password when creating customer")
    void shouldEncryptPasswordWhenCreatingCustomer() {
        // Arrange
        String rawPassword = "password123";
        Customer customer = new Customer(null, "John Doe", "john@example.com", "1234567890", rawPassword, null);
        when(customerRepository.existsByEmail("john@example.com")).thenReturn(false);
        when(customerRepository.save(any(Customer.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        Customer result = customerService.createCustomer(customer);

        // Assert
        assertNotNull(result);
        assertNotEquals(rawPassword, result.getPassword(), "Password should be encrypted and not stored as plain text");
    }
}
