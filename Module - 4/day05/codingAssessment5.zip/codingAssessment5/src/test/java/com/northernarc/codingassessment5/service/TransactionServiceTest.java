package com.northernarc.codingassessment5.service;

import com.northernarc.codingassessment5.model.Account;
import com.northernarc.codingassessment5.model.Transaction;
import com.northernarc.codingassessment5.repository.TransactionRepository;
import com.northernarc.codingassessment5.service.impl.TransactionServiceImpl;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TransactionServiceTest {

    @Mock
    private TransactionRepository transactionRepository;

    @InjectMocks
    private TransactionServiceImpl transactionService;

    @Test
    @DisplayName("Should get all transactions")
    void shouldGetAllTransactions() {
        // Arrange
        List<Transaction> transactions = Arrays.asList(
                new Transaction(1L, "DEPOSIT", new BigDecimal("500.00"), LocalDateTime.now(), "Deposit", null),
                new Transaction(2L, "WITHDRAWAL", new BigDecimal("200.00"), LocalDateTime.now(), "Withdrawal", null)
        );
        when(transactionRepository.findAll()).thenReturn(transactions);

        // Act
        List<Transaction> result = transactionService.getAllTransactions();

        // Assert
        assertNotNull(result);
        assertEquals(2, result.size());
        verify(transactionRepository).findAll();
    }

    @Test
    @DisplayName("Should get transaction by ID")
    void shouldGetTransactionById() {
        // Arrange
        Transaction transaction = new Transaction(1L, "DEPOSIT", new BigDecimal("500.00"), LocalDateTime.now(), "Deposit", null);
        when(transactionRepository.findById(1L)).thenReturn(Optional.of(transaction));

        // Act
        Transaction result = transactionService.getTransactionById(1L);

        // Assert
        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("DEPOSIT", result.getTransactionType());
    }

    @Test
    @DisplayName("Should get transactions by account ID")
    void shouldGetTransactionsByAccountId() {
        // Arrange
        List<Transaction> transactions = Arrays.asList(
                new Transaction(1L, "DEPOSIT", new BigDecimal("500.00"), LocalDateTime.now(), "Deposit", null),
                new Transaction(2L, "WITHDRAWAL", new BigDecimal("100.00"), LocalDateTime.now(), "Withdrawal", null)
        );
        when(transactionRepository.findByAccountId(1L)).thenReturn(transactions);

        // Act
        List<Transaction> result = transactionService.getTransactionsByAccountId(1L);

        // Assert
        assertNotNull(result);
        assertEquals(2, result.size());
        verify(transactionRepository).findByAccountId(1L);
    }

    @Test
    @DisplayName("Should return empty list when no transactions for account")
    void shouldReturnEmptyListWhenNoTransactionsForAccount() {
        // Arrange
        when(transactionRepository.findByAccountId(99L)).thenReturn(Collections.emptyList());

        // Act
        List<Transaction> result = transactionService.getTransactionsByAccountId(99L);

        // Assert
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }
}
