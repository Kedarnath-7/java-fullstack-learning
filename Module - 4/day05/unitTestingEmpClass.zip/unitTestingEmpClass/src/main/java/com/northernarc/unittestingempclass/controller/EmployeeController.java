package com.northernarc.unittestingempclass.controller;

import com.northernarc.unittestingempclass.dto.EmployeeRequestDTO;
import com.northernarc.unittestingempclass.dto.EmployeeResponseDTO;
import com.northernarc.unittestingempclass.service.EmployeeService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @GetMapping
    public List<EmployeeResponseDTO> getAllEmployees() {
        return employeeService.findAll();
    }

    @GetMapping("/{id}")
    public EmployeeResponseDTO getEmployeeById(@PathVariable Long id) {
        return employeeService.findById(id);
    }

    @PostMapping
    public EmployeeResponseDTO addEmployee(EmployeeRequestDTO requestDTO) {
        return employeeService.addEmployee(requestDTO);
    }



}
