package com.northernarc.unittestingempclass;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnitTestingEmpClassApplicationTests {

    @Test
    void contextLoads() {
    }

}
