package com.northernarc.unittestingempclass.controller;

import com.northernarc.unittestingempclass.dto.EmployeeResponseDTO;
import com.northernarc.unittestingempclass.exceptions.EmployeeNotFoundException;
import com.northernarc.unittestingempclass.service.EmployeeService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest
public class EmployeeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private EmployeeService employeeService;

    @Test
    @WithMockUser
    void testGetEmployeeById() throws Exception {
        EmployeeResponseDTO mockResponse = new EmployeeResponseDTO(1L, "John Doe", 50000.0);
        when(employeeService.findById(1L)).thenReturn(mockResponse);

        mockMvc.perform(get("/api/employees/1"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.name").value("John Doe"))
                .andExpect(jsonPath("$.salary").value(50000));
    }

    @Test
    @WithMockUser
    void testGetEmployeeByIdNotFound() throws Exception {
        when(employeeService.findById(1000L)).thenThrow(new EmployeeNotFoundException("Employee not found with id: " + 1000L));

        mockMvc.perform(get("/api/employees/1000"))
                .andExpect(status().isNotFound())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$.message").value("Employee not found with id: 1000"));
    }

}
